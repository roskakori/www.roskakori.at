/*
 * older.h - functions to let a person grow older, header file
 */

/* A simple prototype for the function in older.c */
void grow_older(char *name, int *age);


