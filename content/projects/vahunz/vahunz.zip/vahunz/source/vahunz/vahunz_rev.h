/*
 * This source file is part of Vahunz,
 * a tool to make source code un-/more legible.
 *
 *--------------------------------------------------------------------------
 *
 * Vahunz and the Ugly library are Copyright (C) 1998 by
 * Thomas Aglassinger <agi@giga.or.at>
 *
 * All rights reserved.
 *
 * Refer to the manual for more information.
 *
 *--------------------------------------------------------------------------
 *
 * Ubiqx library is Copyright (C) 1991-1998 by
 * Christopher R. Hertel <crh@ubiqx.mn.org>
 *
 * Ubiqx library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 */
#define j2S 1
#define i9V 6
#define d0P "16.4.1"
#define p9G "vahunz 1.6"
#define i6X "vahunz 1.6 (16.4.1)\r\n"
#define i2Vb "\0$VER: vahunz 1.6 (16.4.1)"
#define v8R "05:06:48"
#define f4Q "vahunz"
#define t4P "VAHUNZ"
#define y1L "vahunz 1.6 (16.4.1)"
#define HOST "yok5094.oulu.fi"
